@echo off
echo 衣橱数据转换工具 - 自动处理脚本
echo 正在启动处理程序...

REM 设置文件路径
set DESKTOP=%USERPROFILE%\Desktop
set INPUT_FILE=%DESKTOP%\大 - 副本.xlsx
set OUTPUT_FILE=%DESKTOP%\大 - 副本_转换结果.xlsx
set SCRIPT_DIR=%~dp0

REM 检查Python是否安装
python --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo 错误：未检测到Python安装，请安装Python 3.6或更高版本。
    echo 您可以从 https://www.python.org/downloads/ 下载Python。
    pause
    exit /b 1
)

REM 检查必要的库是否安装
echo 检查必要的Python库...
python -c "import pandas" >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo 正在安装pandas库...
    pip install pandas
)

python -c "import openpyxl" >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo 正在安装openpyxl库...
    pip install openpyxl
)

REM 检查输入文件是否存在
if not exist "%INPUT_FILE%" (
    echo 错误：未找到输入文件 "%INPUT_FILE%"
    echo 请确保文件"大 - 副本.xlsx"位于桌面上。
    pause
    exit /b 1
)

REM 检查Python脚本是否存在
if not exist "%SCRIPT_DIR%wardrobe_data_converter.py" (
    echo 错误：未找到Python脚本 "%SCRIPT_DIR%wardrobe_data_converter.py"
    echo 请确保将此bat文件与wardrobe_data_converter.py放在同一目录下。
    pause
    exit /b 1
)

REM 运行Python脚本
echo 开始处理Excel文件...
python "%SCRIPT_DIR%wardrobe_data_converter.py" "%INPUT_FILE%" "%OUTPUT_FILE%"

REM 检查处理结果
if %ERRORLEVEL% NEQ 0 (
    echo 处理过程中出现错误，请查看上面的错误信息。
    pause
    exit /b 1
)

echo 处理完成！
echo 转换结果已保存到: %OUTPUT_FILE%
echo.
echo 按任意键打开结果文件...
pause >nul

REM 打开结果文件
start "" "%OUTPUT_FILE%"

exit /b 0

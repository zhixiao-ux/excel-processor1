#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
衣橱数据转换工具 - 简化版 (WPS兼容)
功能：将原表数据转换为CSV格式的转换表，实现以下要求：
1. 原表中数量为负数的行不显示在转换表中
2. 不显示品牌、色号、折扣、明细备注
3. 款号重复的只保留一个
4. 为每个年份创建单独的CSV文件（如"转换表24.csv"、"转换表23.csv"等）

注意：此简化版本无法保留Excel格式设置（如居中对齐、边框等）和图片
"""

import pandas as pd  # 用于数据处理
import xlrd  # 用于读取Excel
import os
import sys
import tkinter as tk
from tkinter import messagebox, filedialog

def convert_wardrobe_data(input_file, output_dir=None):
    """
    将衣橱数据从原表转换为CSV格式的转换表
    
    参数:
        input_file (str): 输入Excel文件路径
        output_dir (str, optional): 输出CSV文件目录，如果不提供则在输入文件同目录下创建
    
    返回:
        str: 输出目录路径
    """
    # 如果未提供输出目录，则在输入文件同目录下创建
    if output_dir is None:
        output_dir = os.path.dirname(input_file)
    
    # 打开原始Excel文件
    print(f"正在打开文件: {input_file}")
    try:
        # 使用xlrd读取原表数据
        wb = xlrd.open_workbook(input_file)
        
        # 检查是否存在"原表"工作表
        sheet_names = wb.sheet_names()
        if "原表" not in sheet_names:
            print("错误：输入文件中没有找到'原表'工作表")
            return None
            
        ws = wb.sheet_by_name("原表")
        
        # 将xlrd工作表转换为pandas DataFrame
        data = []
        for i in range(ws.nrows):
            row = []
            for j in range(ws.ncols):
                row.append(ws.cell_value(i, j))
            data.append(row)
        
        # 创建DataFrame
        headers = data[0]
        df = pd.DataFrame(data[1:], columns=headers)
        
    except Exception as e:
        print(f"打开文件时出错: {e}")
        return None
    
    # 创建需要跳过的列的列表（品牌、色号、折扣、明细备注）
    # 注意：xlrd列索引从0开始，所以这里是第5、10、15、19列
    skip_columns = [headers[5], headers[10], headers[15], headers[19]]
    
    # 收集所有年份（年份在G列，即第6列）
    years_list = df.iloc[:, 6].dropna().unique()
    years_list = [str(year) for year in years_list if str(year).strip()]
    
    # 如果没有找到年份数据，提示用户并退出
    if not years_list:
        print("未找到年份数据，请检查原表G列是否包含年份信息。")
        return None
    
    print(f"找到以下年份: {', '.join(sorted(years_list))}")
    
    # 为每个年份创建一个CSV文件
    for year_item in sorted(years_list):
        # 设置输出文件名
        output_file = os.path.join(output_dir, f"转换表{year_item}.csv")
        print(f"正在创建文件: {output_file}")
        
        # 筛选当前年份的数据
        year_df = df[df.iloc[:, 6].astype(str) == year_item]
        
        # 筛选数量为正数的行（数量在第13列）
        year_df = year_df[pd.to_numeric(year_df.iloc[:, 13], errors='coerce') > 0]
        
        # 去除款号重复的行（款号在第3列）
        year_df = year_df.drop_duplicates(subset=[headers[3]], keep='first')
        
        # 移除不需要的列
        columns_to_keep = [col for col in headers if col not in skip_columns]
        year_df = year_df[columns_to_keep]
        
        # 转置DataFrame（行变列，列变行）
        transposed_df = year_df.transpose()
        
        # 保存为CSV文件
        transposed_df.to_csv(output_file, index=True, header=False, encoding='utf-8-sig')
        
    # 显示处理结果
    years_str = "、".join(sorted(years_list))
    print(f"已为以下年份创建转换表：{years_str}")
    
    return output_dir

def show_gui():
    """显示图形用户界面"""
    root = tk.Tk()
    root.title("衣橱数据转换工具 (简化版)")
    root.geometry("500x300")
    
    # 设置说明文本
    tk.Label(root, text="衣橱数据转换工具 - 简化版 (WPS兼容)", font=("Arial", 14, "bold")).pack(pady=10)
    tk.Label(root, text="将原表数据转换为CSV格式的转换表").pack()
    tk.Label(root, text="请选择包含'原表'工作表的Excel文件").pack(pady=10)
    
    input_file = tk.StringVar()
    output_dir = tk.StringVar()
    
    def browse_input_file():
        filename = filedialog.askopenfilename(
            title="选择Excel文件",
            filetypes=[("Excel文件", "*.xlsx *.xlsm *.xls")]
        )
        if filename:
            input_file.set(filename)
            # 自动设置输出目录为输入文件所在目录
            output_dir.set(os.path.dirname(filename))
    
    def browse_output_dir():
        dirname = filedialog.askdirectory(
            title="选择输出目录"
        )
        if dirname:
            output_dir.set(dirname)
    
    def start_conversion():
        if not input_file.get():
            messagebox.showerror("错误", "请选择输入文件")
            return
        
        try:
            result_dir = convert_wardrobe_data(input_file.get(), output_dir.get())
            if result_dir:
                messagebox.showinfo("成功", f"转换完成！\n结果已保存到：{result_dir}")
            else:
                messagebox.showerror("错误", "转换过程中出现错误，请检查输入文件格式")
        except Exception as e:
            messagebox.showerror("错误", f"转换过程中出现异常：{str(e)}")
    
    # 输入文件选择
    input_frame = tk.Frame(root)
    input_frame.pack(fill="x", padx=20, pady=10)
    tk.Label(input_frame, text="输入文件：").pack(side="left")
    tk.Entry(input_frame, textvariable=input_file, width=40).pack(side="left", padx=5)
    tk.Button(input_frame, text="浏览...", command=browse_input_file).pack(side="left")
    
    # 输出目录选择
    output_frame = tk.Frame(root)
    output_frame.pack(fill="x", padx=20, pady=10)
    tk.Label(output_frame, text="输出目录：").pack(side="left")
    tk.Entry(output_frame, textvariable=output_dir, width=40).pack(side="left", padx=5)
    tk.Button(output_frame, text="浏览...", command=browse_output_dir).pack(side="left")
    
    # 开始转换按钮
    tk.Button(root, text="开始转换", command=start_conversion, 
              font=("Arial", 12), bg="#4CAF50", fg="white", 
              padx=20, pady=10).pack(pady=20)
    
    root.mainloop()

def main():
    """主函数"""
    # 检查命令行参数
    if len(sys.argv) > 1:
        # 命令行模式
        input_file = sys.argv[1]
        output_dir = sys.argv[2] if len(sys.argv) > 2 else None
        convert_wardrobe_data(input_file, output_dir)
    else:
        # 图形界面模式
        show_gui()

if __name__ == "__main__":
    main()

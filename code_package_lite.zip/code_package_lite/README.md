# Excel 衣橱数据处理工具

这个代码包包含了多种解决方案，用于处理Excel衣橱数据，实现以下功能：

1. 按年份创建不同的转换表
2. 筛选数量为正数的行
3. 去除重复款号
4. 跳过指定列（品牌、色号、折扣、明细备注）
5. 设置单元格格式（居中对齐、边框）
6. 设置图片行高和列宽

## 目录结构

```
code_package/
├── README.md                     # 本说明文档
├── wardrobe_data_converter.py    # 完整Python实现（需要独立Python环境）
├── wardrobe_data_converter_wps.py # WPS兼容版本（使用xlrd和xlwt）
├── wardrobe_data_converter_simple.py # 简化版本（仅使用pandas和xlrd）
├── run_converter.bat             # 自动化处理的bat文件
└── web_app/                      # Web应用程序代码
    ├── src/                      # 源代码
    ├── public/                   # 公共资源
    ├── package.json              # 依赖配置
    └── ...                       # 其他配置文件
```

## 解决方案选择指南

根据您的需求和环境，您可以选择以下解决方案之一：

### 1. Python脚本 + BAT文件（推荐）

最可靠的本地解决方案，适合有独立Python环境的用户。

**使用方法：**
1. 安装Python 3.6或更高版本
2. 安装依赖：`pip install pandas openpyxl`
3. 将`wardrobe_data_converter.py`和`run_converter.bat`放在同一个文件夹中
4. 确保桌面上有"大 - 副本.xlsx"文件
5. 双击运行`run_converter.bat`文件

### 2. WPS兼容版本

适合在WPS环境中运行的版本，使用xlrd和xlwt库。

**使用方法：**
1. 在WPS中打开Python编辑器
2. 复制`wardrobe_data_converter_wps.py`的内容
3. 运行代码，使用图形界面选择Excel文件

### 3. 简化版本

最简化的版本，只使用pandas和xlrd库，输出CSV格式。

**使用方法：**
1. 在WPS中打开Python编辑器
2. 复制`wardrobe_data_converter_simple.py`的内容
3. 修改代码中的文件路径
4. 运行代码

### 4. Web应用程序（在线解决方案）

可从任何地方访问的在线解决方案，需要部署到互联网上。

**部署方法：**
1. 创建GitHub账号和仓库
2. 上传`web_app`目录中的代码
3. 注册Vercel账号
4. 使用Vercel部署GitHub仓库

详细的部署指南请参考下面的"Web应用程序部署指南"部分。

## Web应用程序部署指南

### 详细部署步骤

1. **创建GitHub账号**（如果您还没有）
   - 访问 https://github.com/signup
   - 按照指示完成注册

2. **创建GitHub仓库**
   - 登录GitHub后，点击右上角的"+"图标，选择"New repository"
   - 仓库名称输入"excel-processor"
   - 选择"Public"（公开）
   - 点击"Create repository"

3. **上传代码到GitHub**
   - 解压下载的文件
   - 按照GitHub页面上的指示上传代码（GitHub会提供详细步骤）
   - 通常包括以下命令：
     ```
     git init
     git add .
     git commit -m "Initial commit"
     git branch -M main
     git remote add origin https://github.com/您的用户名/excel-processor.git
     git push -u origin main
     ```

4. **注册Vercel账号**
   - 访问 https://vercel.com/signup
   - 选择"Continue with GitHub"（使用GitHub账号登录）
   - 按照指示完成注册

5. **部署项目**
   - 登录Vercel后，点击"New Project"
   - 选择您刚才创建的GitHub仓库"excel-processor"
   - 保持默认设置不变
   - 点击"Deploy"

6. **等待部署完成**
   - Vercel会自动构建和部署您的应用
   - 部署完成后，您会获得一个永久的网址（例如：https://excel-processor.vercel.app）
   - 这个网址是永久的，您可以随时访问

7. **自定义域名**（可选）
   - 如果您拥有自己的域名，可以在Vercel的项目设置中添加
   - 点击项目 → Settings → Domains → Add
   - 按照指示完成域名设置

## 注意事项

1. 所有解决方案都要求Excel文件包含名为"原表"的工作表
2. 年份信息必须位于G列（第7列）
3. 数量信息必须位于第14列
4. 款号信息必须位于第4列

## 技术支持

如果您在使用过程中遇到任何问题，或者需要进一步的帮助，请随时联系我们。

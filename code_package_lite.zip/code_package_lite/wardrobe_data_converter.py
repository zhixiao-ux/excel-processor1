#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
衣橱数据转换工具 - Python版本
功能：将原表数据转换为转换表格式，实现以下要求：
1. 文字居中显示
2. 原表中数量为负数的行不显示在转换表中
3. 保留表格边框
4. 确保图片正确显示
5. 图片行高设置为180
6. 图片列宽设置为18
7. 不显示品牌、色号、折扣、明细备注
8. 款号重复的只保留一个
9. 为每个年份创建单独的转换表（如"转换表24"、"转换表23"等）
"""

import pandas as pd
import openpyxl
from openpyxl.styles import Alignment, Border, Side
from openpyxl.utils import get_column_letter
import re
import os
import sys
import tkinter as tk
from tkinter import messagebox, filedialog

def convert_wardrobe_data(input_file, output_file=None):
    """
    将衣橱数据从原表转换为特定格式的转换表
    
    参数:
        input_file (str): 输入Excel文件路径
        output_file (str, optional): 输出Excel文件路径，如果不提供则在输入文件同目录下创建
    
    返回:
        str: 输出文件路径
    """
    # 如果未提供输出文件路径，则在输入文件同目录下创建
    if output_file is None:
        file_dir = os.path.dirname(input_file)
        file_name = os.path.splitext(os.path.basename(input_file))[0]
        output_file = os.path.join(file_dir, f"{file_name}_转换结果.xlsx")
    
    # 打开原始Excel文件
    print(f"正在打开文件: {input_file}")
    try:
        # 使用openpyxl读取原始文件以获取完整信息（包括图片和格式）
        wb_source = openpyxl.load_workbook(input_file, data_only=False)
        
        # 检查是否存在"原表"工作表
        if "原表" not in wb_source.sheetnames:
            print("错误：输入文件中没有找到'原表'工作表")
            return None
            
        ws_source = wb_source["原表"]
    except Exception as e:
        print(f"打开文件时出错: {e}")
        return None
    
    # 创建新的Excel工作簿
    wb_target = openpyxl.Workbook()
    # 删除默认创建的Sheet
    if "Sheet" in wb_target.sheetnames:
        wb_target.remove(wb_target["Sheet"])
    
    # 获取原表的数据范围
    last_row = ws_source.max_row
    last_col = ws_source.max_column
    
    # 创建需要跳过的列的集合（品牌、色号、折扣、明细备注）
    skip_columns = {6, 11, 16, 20}  # 对应VBA中的第6、11、16、20列
    
    # 收集所有年份（年份在G列，即第7列）
    years_list = set()
    for i in range(2, last_row + 1):
        cell_value = ws_source.cell(row=i, column=7).value
        if cell_value is not None:
            year_value = str(cell_value)
            if year_value and year_value not in years_list:
                years_list.add(year_value)
    
    # 如果没有找到年份数据，提示用户并退出
    if not years_list:
        print("未找到年份数据，请检查原表G列是否包含年份信息。")
        return None
    
    print(f"找到以下年份: {', '.join(sorted(years_list))}")
    
    # 为每个年份创建一个工作表
    for year_item in sorted(years_list):
        # 创建该年份的款号字典，用于跟踪已处理的款号
        unique_styles = set()
        
        # 设置目标工作表名称
        target_sheet_name = f"转换表{year_item}"
        print(f"正在创建工作表: {target_sheet_name}")
        
        # 创建新工作表
        ws_target = wb_target.create_sheet(title=target_sheet_name)
        
        # 在转换表中设置表头
        ws_target.cell(row=1, column=1, value="图片")
        ws_target.cell(row=1, column=16, value="合计")
        
        # 设置转换表的行标题（使用原表的列标题，跳过指定列）
        target_row_index = 1
        for i in range(1, last_col + 1):
            # 跳过不需要显示的列
            if i not in skip_columns:
                ws_target.cell(row=target_row_index, column=1, value=ws_source.cell(row=1, column=i).value)
                target_row_index += 1
        
        # 初始化转换表当前列
        target_col = 2
        
        # 遍历原表数据行
        for i in range(2, last_row + 1):
            # 获取当前行的数量值（第14列）
            quantity_cell = ws_source.cell(row=i, column=14)
            quantity = quantity_cell.value
            if quantity is None:
                quantity = 0
            
            # 尝试将数量转换为数字
            try:
                quantity = float(quantity)
            except (ValueError, TypeError):
                quantity = 0
            
            # 获取款号（第4列）
            style_code_cell = ws_source.cell(row=i, column=4)
            style_code = str(style_code_cell.value or "")
            
            # 获取年份（G列，第7列）
            year_cell = ws_source.cell(row=i, column=7)
            year_value = str(year_cell.value or "")
            
            # 只处理当前年份的数据，数量为正数的行，且款号不重复
            if (year_value == year_item and 
                quantity > 0 and 
                (not style_code or style_code not in unique_styles)):
                
                # 如果款号不为空，则添加到已处理款号集合中
                if style_code:
                    unique_styles.add(style_code)
                
                # 填充转换表数据
                target_row_index = 1
                
                for j in range(1, last_col + 1):
                    # 跳过不需要显示的列
                    if j not in skip_columns:
                        # 获取原表单元格的值
                        source_cell = ws_source.cell(row=i, column=j)
                        cell_value = source_cell.value
                        
                        # 如果是图片列（第1列）
                        if j == 1:
                            # 检查是否包含DISPIMG函数
                            if cell_value and isinstance(cell_value, str) and "DISPIMG" in cell_value:
                                # 将原表中的图片公式复制到转换表中
                                # 注意：将参数从1改为0（原表用1，转换表用0）
                                cell_value = cell_value.replace(",1)", ",0)")
                                ws_target.cell(row=1, column=target_col, value=cell_value)
                                
                                # 注意：DISPIMG是Excel中的自定义函数，Python中无法直接执行
                                # 在实际应用中，可能需要提取图片并使用openpyxl的图片插入功能
                                # 这里我们只是保留了原始公式，实际效果需要在Excel中查看
                        else:
                            # 复制其他数据
                            target_cell = ws_target.cell(row=target_row_index, column=target_col, value=cell_value)
                            
                            # 尝试复制单元格格式（如果有）
                            try:
                                if source_cell.has_style:
                                    target_cell.font = source_cell.font
                                    target_cell.fill = source_cell.fill
                                    target_cell.number_format = source_cell.number_format
                            except:
                                pass  # 忽略格式复制错误
                        
                        target_row_index += 1
                
                # 移动到转换表的下一列
                target_col += 1
        
        # 设置单元格格式为居中对齐
        for row in ws_target.iter_rows():
            for cell in row:
                cell.alignment = Alignment(horizontal='center', vertical='center')
        
        # 设置表格边框
        thin_border = Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )
        
        for row in ws_target.iter_rows(min_row=1, max_row=ws_target.max_row, 
                                      min_col=1, max_col=ws_target.max_column):
            for cell in row:
                cell.border = thin_border
        
        # 设置图片行的高度为180
        ws_target.row_dimensions[1].height = 180
        
        # 设置所有列的宽度为18
        for i in range(2, target_col):
            ws_target.column_dimensions[get_column_letter(i)].width = 18
    
    # 保存结果
    print(f"正在保存结果到: {output_file}")
    wb_target.save(output_file)
    
    # 显示处理结果
    years_str = "、".join(sorted(years_list))
    print(f"已为以下年份创建转换表：{years_str}")
    
    return output_file

def show_gui():
    """显示图形用户界面"""
    root = tk.Tk()
    root.title("衣橱数据转换工具")
    root.geometry("500x300")
    
    # 设置说明文本
    tk.Label(root, text="衣橱数据转换工具 - Python版本", font=("Arial", 14, "bold")).pack(pady=10)
    tk.Label(root, text="将原表数据转换为特定格式的转换表").pack()
    tk.Label(root, text="请选择包含'原表'工作表的Excel文件").pack(pady=10)
    
    input_file = tk.StringVar()
    output_file = tk.StringVar()
    
    def browse_input_file():
        filename = filedialog.askopenfilename(
            title="选择Excel文件",
            filetypes=[("Excel文件", "*.xlsx *.xlsm *.xls")]
        )
        if filename:
            input_file.set(filename)
            # 自动设置输出文件路径
            file_dir = os.path.dirname(filename)
            file_name = os.path.splitext(os.path.basename(filename))[0]
            output_file.set(os.path.join(file_dir, f"{file_name}_转换结果.xlsx"))
    
    def browse_output_file():
        filename = filedialog.asksaveasfilename(
            title="保存转换结果",
            defaultextension=".xlsx",
            filetypes=[("Excel文件", "*.xlsx")]
        )
        if filename:
            output_file.set(filename)
    
    def start_conversion():
        if not input_file.get():
            messagebox.showerror("错误", "请选择输入文件")
            return
        
        try:
            result_file = convert_wardrobe_data(input_file.get(), output_file.get())
            if result_file:
                messagebox.showinfo("成功", f"转换完成！\n结果已保存到：{result_file}")
            else:
                messagebox.showerror("错误", "转换过程中出现错误，请检查输入文件格式")
        except Exception as e:
            messagebox.showerror("错误", f"转换过程中出现异常：{str(e)}")
    
    # 输入文件选择
    input_frame = tk.Frame(root)
    input_frame.pack(fill="x", padx=20, pady=10)
    tk.Label(input_frame, text="输入文件：").pack(side="left")
    tk.Entry(input_frame, textvariable=input_file, width=40).pack(side="left", padx=5)
    tk.Button(input_frame, text="浏览...", command=browse_input_file).pack(side="left")
    
    # 输出文件选择
    output_frame = tk.Frame(root)
    output_frame.pack(fill="x", padx=20, pady=10)
    tk.Label(output_frame, text="输出文件：").pack(side="left")
    tk.Entry(output_frame, textvariable=output_file, width=40).pack(side="left", padx=5)
    tk.Button(output_frame, text="浏览...", command=browse_output_file).pack(side="left")
    
    # 开始转换按钮
    tk.Button(root, text="开始转换", command=start_conversion, 
              font=("Arial", 12), bg="#4CAF50", fg="white", 
              padx=20, pady=10).pack(pady=20)
    
    root.mainloop()

def main():
    """主函数"""
    # 检查命令行参数
    if len(sys.argv) > 1:
        # 命令行模式
        input_file = sys.argv[1]
        output_file = sys.argv[2] if len(sys.argv) > 2 else None
        convert_wardrobe_data(input_file, output_file)
    else:
        # 图形界面模式
        show_gui()

if __name__ == "__main__":
    main()

import Link from 'next/link'

export default function Home() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 bg-gray-50">
      <div className="w-full max-w-3xl p-8 bg-white rounded-lg shadow-lg">
        <h1 className="mb-6 text-3xl font-bold text-center text-blue-600">Excel文件处理工具</h1>
        
        <div className="mb-8 p-4 bg-blue-50 rounded-lg">
          <h2 className="text-xl font-semibold mb-2">功能介绍</h2>
          <p className="mb-2">这个工具可以帮助您处理Excel文件，实现以下功能：</p>
          <ul className="list-disc pl-5 space-y-1">
            <li>按年份创建不同的转换表</li>
            <li>筛选数量为正数的行</li>
            <li>去除重复款号</li>
            <li>跳过指定列（品牌、色号、折扣、明细备注）</li>
            <li>设置单元格格式（居中对齐、边框）</li>
            <li>设置图片行高和列宽</li>
          </ul>
        </div>
        
        <div className="mb-8">
          <h2 className="text-xl font-semibold mb-4">开始使用</h2>
          <Link 
            href="/upload" 
            className="block w-full py-3 px-4 text-center text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition duration-200"
          >
            上传Excel文件
          </Link>
        </div>
        
        <div className="p-4 bg-gray-100 rounded-lg">
          <h2 className="text-xl font-semibold mb-2">使用说明</h2>
          <ol className="list-decimal pl-5 space-y-2">
            <li>点击"上传Excel文件"按钮</li>
            <li>选择您的Excel文件（必须包含"原表"工作表）</li>
            <li>点击"处理文件"按钮</li>
            <li>等待处理完成后，下载处理结果</li>
          </ol>
        </div>
      </div>
    </div>
  )
}

import { NextRequest, NextResponse } from 'next/server';
import { promises as fs } from 'fs';
import path from 'path';
import * as XLSX from 'xlsx';
import { IncomingForm } from 'formidable';
import { mkdir, writeFile } from 'fs/promises';

// 禁用默认的bodyParser，以便我们可以使用formidable解析表单数据
export const config = {
  api: {
    bodyParser: false,
  },
};

// 处理文件上传的函数
async function parseForm(req) {
  return new Promise((resolve, reject) => {
    const form = new IncomingForm({
      uploadDir: path.join(process.cwd(), 'public/uploads'),
      keepExtensions: true,
      maxFileSize: 10 * 1024 * 1024, // 10MB
    });

    form.parse(req, (err, fields, files) => {
      if (err) return reject(err);
      resolve({ fields, files });
    });
  });
}

// 处理Excel文件的函数
async function processExcelFile(filePath) {
  try {
    // 读取Excel文件
    const workbook = XLSX.readFile(filePath);
    
    // 检查是否存在"原表"工作表
    if (!workbook.Sheets['原表']) {
      throw new Error('输入文件中没有找到"原表"工作表');
    }
    
    // 获取原表数据
    const originalSheet = workbook.Sheets['原表'];
    const originalData = XLSX.utils.sheet_to_json(originalSheet, { header: 1 });
    
    // 获取表头
    const headers = originalData[0];
    
    // 创建需要跳过的列的索引（品牌、色号、折扣、明细备注）
    // 注意：这里假设这些列的索引是5, 10, 15, 19（对应第6、11、16、20列）
    const skipColumns = [5, 10, 15, 19];
    
    // 收集所有年份（年份在G列，即第7列，索引为6）
    const yearColumnIndex = 6;
    const years = new Set();
    for (let i = 1; i < originalData.length; i++) {
      const row = originalData[i];
      if (row && row[yearColumnIndex]) {
        const year = String(row[yearColumnIndex]).trim();
        if (year) {
          years.add(year);
        }
      }
    }
    
    // 如果没有找到年份数据，抛出错误
    if (years.size === 0) {
      throw new Error('未找到年份数据，请检查原表G列是否包含年份信息');
    }
    
    // 为每个年份创建一个工作表
    const resultWorkbook = XLSX.utils.book_new();
    const yearsList = Array.from(years).sort();
    
    for (const year of yearsList) {
      // 创建该年份的款号集合，用于跟踪已处理的款号
      const uniqueStyles = new Set();
      
      // 设置目标工作表名称
      const targetSheetName = `转换表${year}`;
      
      // 筛选当前年份的数据，数量为正数的行
      const yearData = originalData.slice(1).filter(row => {
        if (!row || row.length <= yearColumnIndex) return false;
        
        // 检查年份
        const rowYear = String(row[yearColumnIndex]).trim();
        if (rowYear !== year) return false;
        
        // 检查数量（数量在第14列，索引为13）
        const quantity = parseFloat(row[13]);
        if (isNaN(quantity) || quantity <= 0) return false;
        
        // 检查款号（款号在第4列，索引为3）
        const styleCode = String(row[3] || '').trim();
        if (styleCode && uniqueStyles.has(styleCode)) return false;
        
        // 添加款号到已处理集合
        if (styleCode) {
          uniqueStyles.add(styleCode);
        }
        
        return true;
      });
      
      // 创建转换表数据
      const transposedData = [];
      
      // 添加表头行
      transposedData.push(['图片', ...yearData.map(() => '')]);
      
      // 添加数据行
      for (let colIndex = 0; colIndex < headers.length; colIndex++) {
        // 跳过不需要显示的列
        if (skipColumns.includes(colIndex)) continue;
        
        const rowData = [headers[colIndex]];
        
        // 添加每个款号的数据
        for (const row of yearData) {
          rowData.push(row[colIndex]);
        }
        
        transposedData.push(rowData);
      }
      
      // 添加合计行
      transposedData[0][transposedData[0].length - 1] = '合计';
      
      // 创建工作表
      const ws = XLSX.utils.aoa_to_sheet(transposedData);
      
      // 设置单元格格式
      const range = XLSX.utils.decode_range(ws['!ref']);
      for (let r = range.s.r; r <= range.e.r; r++) {
        for (let c = range.s.c; c <= range.e.c; c++) {
          const cell_address = XLSX.utils.encode_cell({ r, c });
          if (!ws[cell_address]) continue;
          
          // 设置居中对齐
          if (!ws[cell_address].s) ws[cell_address].s = {};
          ws[cell_address].s.alignment = { horizontal: 'center', vertical: 'center' };
          
          // 设置边框
          if (!ws[cell_address].s.border) ws[cell_address].s.border = {};
          ws[cell_address].s.border = {
            top: { style: 'thin' },
            bottom: { style: 'thin' },
            left: { style: 'thin' },
            right: { style: 'thin' }
          };
        }
      }
      
      // 设置图片行的高度为180
      ws['!rows'] = [{ hpt: 180 }];
      
      // 设置所有列的宽度为18
      ws['!cols'] = Array(transposedData[0].length).fill({ wch: 18 });
      
      // 将工作表添加到工作簿
      XLSX.utils.book_append_sheet(resultWorkbook, ws, targetSheetName);
    }
    
    // 生成结果文件
    const resultFilePath = path.join(process.cwd(), 'public/uploads', `处理结果_${Date.now()}.xlsx`);
    XLSX.writeFile(resultWorkbook, resultFilePath);
    
    // 返回结果文件的相对路径
    return path.relative(process.cwd(), resultFilePath);
  } catch (error) {
    console.error('处理Excel文件时出错:', error);
    throw error;
  }
}

// API路由处理函数
export async function POST(req) {
  try {
    // 确保上传目录存在
    const uploadDir = path.join(process.cwd(), 'public/uploads');
    try {
      await fs.access(uploadDir);
    } catch (error) {
      await mkdir(uploadDir, { recursive: true });
    }
    
    // 解析表单数据
    const { files } = await parseForm(req);
    const file = files.file[0];
    
    if (!file) {
      return NextResponse.json({ error: '没有上传文件' }, { status: 400 });
    }
    
    // 处理Excel文件
    const resultFilePath = await processExcelFile(file.filepath);
    
    // 返回结果
    return NextResponse.json({ 
      success: true, 
      message: '文件处理成功',
      resultFile: `/uploads/${path.basename(resultFilePath)}`
    });
  } catch (error) {
    console.error('API错误:', error);
    return NextResponse.json({ 
      error: error.message || '处理文件时出错' 
    }, { status: 500 });
  }
}

'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function Upload() {
  const [file, setFile] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState('');
  const [result, setResult] = useState(null);

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    setFile(selectedFile);
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!file) {
      setError('请选择一个Excel文件');
      return;
    }

    // 检查文件类型
    if (!file.name.endsWith('.xlsx') && !file.name.endsWith('.xls')) {
      setError('请上传Excel文件 (.xlsx 或 .xls)');
      return;
    }

    setIsUploading(true);
    setError('');

    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || '上传文件时出错');
      }

      setResult(data);
    } catch (err) {
      console.error('上传错误:', err);
      setError(err.message || '处理文件时出错');
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4 bg-gray-50">
      <div className="w-full max-w-3xl p-8 bg-white rounded-lg shadow-lg">
        <h1 className="mb-6 text-3xl font-bold text-center text-blue-600">上传Excel文件</h1>
        
        {!result ? (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">
                选择Excel文件
              </label>
              <input
                type="file"
                onChange={handleFileChange}
                className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                accept=".xlsx,.xls"
              />
              <p className="mt-1 text-sm text-gray-500">
                请上传包含"原表"工作表的Excel文件
              </p>
            </div>

            {error && (
              <div className="p-3 text-sm text-red-700 bg-red-100 rounded-md">
                {error}
              </div>
            )}

            <div className="flex items-center justify-between">
              <Link
                href="/"
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
              >
                返回首页
              </Link>
              <button
                type="submit"
                disabled={isUploading || !file}
                className={`px-4 py-2 text-sm font-medium text-white rounded-md ${
                  isUploading || !file
                    ? 'bg-blue-400 cursor-not-allowed'
                    : 'bg-blue-600 hover:bg-blue-700'
                }`}
              >
                {isUploading ? '处理中...' : '处理文件'}
              </button>
            </div>
          </form>
        ) : (
          <div className="space-y-6">
            <div className="p-4 text-sm text-green-700 bg-green-100 rounded-md">
              <p className="font-medium">文件处理成功！</p>
              <p className="mt-1">您的Excel文件已成功处理。</p>
            </div>

            <div className="flex flex-col items-center p-6 space-y-4 text-center border-2 border-dashed border-gray-300 rounded-md">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="w-12 h-12 text-green-500"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
              <h3 className="text-lg font-medium">处理完成</h3>
              <p className="text-sm text-gray-500">
                点击下方按钮下载处理结果
              </p>
              <a
                href={result.resultFile}
                download
                className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700"
              >
                下载结果文件
              </a>
            </div>

            <div className="flex justify-between">
              <Link
                href="/"
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
              >
                返回首页
              </Link>
              <button
                onClick={() => {
                  setFile(null);
                  setResult(null);
                }}
                className="px-4 py-2 text-sm font-medium text-blue-700 bg-blue-100 rounded-md hover:bg-blue-200"
              >
                处理另一个文件
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
